# weeds-wvc-2024

$ conda env create -f env-breakhis-py310.yml